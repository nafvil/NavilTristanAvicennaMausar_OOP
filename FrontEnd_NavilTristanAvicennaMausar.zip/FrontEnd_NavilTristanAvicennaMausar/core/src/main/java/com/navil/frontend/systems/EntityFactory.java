package com.navil.frontend.systems;

public class EntityFactory {
}

package com.navil.frontend.systems;

/**
 * Mediator that centralizes all collision interactions between entities.
 */
public class CollisionReferee {

    public void resolveCollisions() {
        // Hehe, leave this empty for now
    }
}
